import { initializeApp } from 'firebase/app'
import { getAuth } from 'firebase/auth'
import { getFirestore } from 'firebase/firestore'

// ============================================================
// COLA AQUI A CONFIGURAÇÃO DO TEU PROJETO FIREBASE
// (Vais buscar isto em: Firebase Console > Definições do projeto > Geral > As tuas apps > SDK setup)
// ============================================================
const firebaseConfig = {
  apiKey: "COLA_AQUI",
  authDomain: "COLA_AQUI.firebaseapp.com",
  projectId: "COLA_AQUI",
  storageBucket: "COLA_AQUI.appspot.com",
  messagingSenderId: "COLA_AQUI",
  appId: "COLA_AQUI"
}

const app = initializeApp(firebaseConfig)
export const auth = getAuth(app)
export const db = getFirestore(app)
